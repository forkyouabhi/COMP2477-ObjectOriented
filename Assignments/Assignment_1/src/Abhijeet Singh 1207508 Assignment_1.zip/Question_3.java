public class Question_3 {


    public static String boolToString(boolean value) {
        return Boolean.toString(value);
    }

    public static void main(String[] args) {

        System.out.println(boolToString(true));
        System.out.println(boolToString(false));
    }
}
